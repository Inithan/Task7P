package com.book.tcs.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "book")
public class Book {

    private String isbn;
    private String title;
    private Date published_Date;
    private int total_Copies;
    private int issued_Copies;
    private String author;
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getPublished_Date() {
		return published_Date;
	}
	public void setPublished_Date(Date published_Date) {
		this.published_Date = published_Date;
	}
	public int getTotal_Copies() {
		return total_Copies;
	}
	public void setTotal_Copies(int total_Copies) {
		this.total_Copies = total_Copies;
	}
	public int getIssued_Copies() {
		return issued_Copies;
	}
	public void setIssued_Copies(int issued_Copies) {
		this.issued_Copies = issued_Copies;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + ((isbn == null) ? 0 : isbn.hashCode());
		result = prime * result + issued_Copies;
		result = prime * result + ((published_Date == null) ? 0 : published_Date.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + total_Copies;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		if (isbn == null) {
			if (other.isbn != null)
				return false;
		} else if (!isbn.equals(other.isbn))
			return false;
		if (issued_Copies != other.issued_Copies)
			return false;
		if (published_Date == null) {
			if (other.published_Date != null)
				return false;
		} else if (!published_Date.equals(other.published_Date))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (total_Copies != other.total_Copies)
			return false;
		return true;
	}
	public Book(String isbn, String title, Date published_Date, int total_Copies, int issued_Copies, String author) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.published_Date = published_Date;
		this.total_Copies = total_Copies;
		this.issued_Copies = issued_Copies;
		this.author = author;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", published_Date=" + published_Date + ", total_Copies="
				+ total_Copies + ", issued_Copies=" + issued_Copies + ", author=" + author + "]";
	}
    
    
    
}

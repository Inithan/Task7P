package com.book.tcs.service;

import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl {

}

package com.book.tcs.repository;

public interface BookRepository {

}

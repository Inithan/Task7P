package com.book.tcs.service;


public interface BookService {

	
}

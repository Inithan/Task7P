CREATE TABLE book (
    sbn INT PRIMARY KEY,
    title VARCHAR(255),
    published_Date DATE,
    total_Copies INT,
    issued_Copies INT,
    author VARCHAR(255)
);

commit;

INSERT INTO book (sbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (123456789, 'The Adventures of SQL', '2022-01-15', 100, 20, 'John Doe');
INSERT INTO book (sbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (987654321, 'Database Chronicles', '2022-02-20', 150, 30, 'Jane Smith');
INSERT INTO book (sbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (456789012, 'SQL Mastery', '2022-03-10', 80, 10, 'Bob Johnson');
INSERT INTO book (sbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (321098765, 'Data Wonderland', '2022-04-05', 120, 25, 'Alice Davis');
INSERT INTO book (sbn, title, published_Date, total_Copies, issued_Copies, author)
VALUES (789012345, 'Queries Unleashed', '2022-05-12', 200, 40, 'Charlie Brown');

commit;
